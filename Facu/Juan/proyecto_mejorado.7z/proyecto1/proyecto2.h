/*DUDAS:
1) en mi class CADolares() el metodo SaldoInsuficiente es necesario o puedo hacerlo
   directamente del metodo Extraccion?podes hacerlo directament en extraccion
2) para el el metodo deposito y extraccion de mi class CADolares es necesario ponerle
   parametros?si
3) en necesario en mi clase TransaccionPeso() poner un atributo tipoTransaccion()
   ya que sera en pesos la transaccion. Lo unico que no se como diferenciarlar al momento
   de guardo por eso le agrego dicho atributo.no es necesario
4)  deberia implementar los destructores en cada clase?no
5) el metodo Deposito() y Extraccion() estan bien definidos en la class CADolares y CAPesos
   o seria mejor definirlos en la class Cliente?mejor en la calse cliengte yb que pase un parametro que defina que tipo de extraccion es
6) si cada cliente tiene una CADolares y otra Pesos entonces deberia crear dos clases
   ClientePlataDolares/ClientePlataPesos    no
7) Es necesario al clientePlata crearle los metodos extraccion/deposito si
   la class clientes ya los tiene?no es necesario
8) Atributos//Metodos de la class TarjetaOro.. revisarlos!
9) class Cliente. Ver dudas en atributos.
*/

#include <iostream>
#include <string.h>
using namespace std;

//enum {
//    BAJO = 0,
//    ACTIVO
//};

class DatosPersonas
{

protected:
    long dni;
    string nombre;
    int anioIngreso;
    bool estado; //activo o baja

public:
    DatosPersonas();
    DatosPersonas(long, string, int, bool);

    void setDni(long);
    void setNombre(string);
    void setAnioIngreso(int);
    void setEstado(bool);

    long getDni();
    string getNombre();
    int getAnioIngreso();
    bool getEstado();
};

class Personal : public DatosPersonas
{
private:
    string cargo;

public:
    Personal();
    Personal(long, string, int, char, string);

    void setCargo(string);
    
    string getCargo();
    
    void mostrarDatosPersonal();
};

class Transacciones
{
private:
    string fecha;
    float monto;
    char tipoTransaccion; // si es Deposito(D) o Extraccion(E)
    char moneda; // si es Dolares(D) o Pesos(P)
    string descripcion;
    string nroCuenta;  // que caja de ahorro es

public:
    Transacciones();
    Transacciones(string, float, char, char, string, string);

    void setFecha(string);
    void setMonto(float);
    void setTipoTransaccion(char);
    void setMonedaTransaccion(char);
    void setDescripcion(string);
    void setNroCuenta (string);

    string getFecha();
    float getMonto();
    char getTipoTransaccion();
    char getMonedaTransaccion();
    string getDescripcion();

    void registrarEnArchivo();
    void mostrarTransaccion();
};

class CajasAhorro
{

private:
    float saldo;
    string numeroCta;
    string moneda; // (US$ o AR$)

public:
    CajasAhorro();
    CajasAhorro(float, string, string);

    void setSaldo (float);
    void setNumeroCta(string);
    void setMoneda(string);

    float getSaldo();
    string getNumeroCta();
    string getMoneda();

    void deposito(float);

    void extraccion(float);

    void mostrarSaldo();
};

// class TransaccionPesos
// {
// private:
//     int fecha;
//     float saldo;
//     char tipoTran; // si es Deposito(D) o Extraccion(E)
//     int descripcion;

// public:
//     TransaccionPesos();
//     TransaccionPesos(int, float, char, int);

//     void setFechaPesos(int);
//     void setMontoPesos(float);
//     void setTipoTranPesos(char);
//     void setDescripcionPesos(int);

//     int getFechaPesos();
//     float getMontoPesos();
//     char getTipoTranPesos();
//     int getDescripcionPesos();

//     void registrarEnArchivoPesos(); // duda
//     void mostrarTransaccionPesos(); // duda
// };

// class CAPesos
// {

// private:
//     float saldoPesos;
//     string numeroCtaPesos;
//     string titularPesos;
//     long usuarioPesos;
//     long clavePesos;
//     TransaccionPesos tranPesos;

// public:
//     CAPesos();
//     CAPesos(float, string, string, long, long, TransaccionPesos);

//     void setSaldoPesos(float);
//     void setNumeroCtaPesos(string);
//     void setTitularPesos(string);
//     void setUsuarioPesos(long);
//     void setClavePesos(long);

//     float getSaldoPesos();
//     string getNumeroCtaPesos();
//     string getTitularPesos();
//     long getUsuarioPesos();
//     long getClavePesos();

//     void deposito(float);   // duda
//     void extraccion(float); // duda
//     void mostrarSaldo();
//     void saldoInsuficiente(); // duda
//     void estadoDeCuenta();    // muestra transacciones
// };

class Cliente : public DatosPersonas
{

private:
    string tipoCliente;
    // string clientePlata; //no acceso tarjeta credito
    // string clienteOro; //acceso tarjeta credito. limite 250mil
    // string clientePlatino; //acceso tarjeta credito. limite 500mil     
    CajasAhorro CAhorroP;
    CajasAhorro CAhorroD;

public:
    Cliente();
    Cliente(long, string, int,bool, string, CajasAhorro, CajasAhorro);

    void setTipoCliente (string);
    void setCAhorroD(CajasAhorro);
    void setCAhorroP(CajasAhorro);

    string getTipoCliente();
    CajasAhorro& getCAhorroP();
    CajasAhorro& getCAhorroD();

    void deposito(float, char tipo);
    void extraccion(float, char tipo);
    void registrarDatosClientes(); 
    void mostrarDatosCliente();
    void mostrarCAhorroD();
    void mostrarCAhorroP();

};

// class ClientePlata : public Cliente
// {

// private:
//     string titularPlata;
//     long usuarioPlata;
//     long clavePlata;
//     float saldoPlata;

// public:
//     ClientePlata();
//     ClientePlata(char, char, CADolares, CAPesos, string, long, long, float);

//     void setTitularPlata(string);
//     void setUsuarioPlata(long);
//     void setClavePlata(long);
//     void setSaldoPlata(float);

//     string getTitularPlata();
//     long getUsuarioPlata();
//     long getClavePlata();
//     float getSaldoPlata();

//     void mostrarSaldoClientePlata(); // duda
//     void Extraccion();               // duda
//     void Desposito();                // duda
// };

// class TarjetaOro
// {

// private:
//     int limiteOro; //$250.000 <- settear por default
//     string titularOro;
//     long numeroTarjetaOro;
//     int codigoSegOro;
//     int fechaVencimientoOro;
//     float saldoOro;

// public:
//     TarjetaOro();
//     TarjetaOro(int, string, long, int, int, float);

//     void setLimiteOro(int);
//     void setTitularOro(string);
//     void setNumeroTarjetaOro(long);
//     void setCodigoSegOro(int);
//     void setFechaVencimientoTarOro(int);
//     void setSaldoOro(float);

//     int getLimiteOro();
//     string getTitularOro();
//     long getNumeroTarjetaOro();
//     int getCodigoSegOro();
//     int getFechaVencimientoTarOro();
//     float getSaldoOro();

//     void mostrarSaldoTarjetaOro();  // muestra saldo disponible para gastar
//     void mostrarGastosTarjetaOro(); // muestra transacciones
// };

// class ClienteOro : public Cliente
// {

// private:
//     string titularOro;
//     long usarioOro;
//     long claveOro;
//     float saldoOro;
//     TarjetaOro TarOro1;

// public:
//     ClienteOro();
//     ClienteOro(char, char, CADolares, CAPesos, string, long, long, float, TarjetaOro);

//     void setTitularOro(string);
//     void setUsuarioOro(long);
//     void setClaveOro(long);
//     void setSaldoOro(float);

//     string getTitularOro();
//     long getUsuarioOro();
//     long getClaveOro();
//     float getSaldoOro();

//     void mostrarSaldoClienteOro();
//     void Extraccion();
//     void Desposito();
// };

// class TarjetaPlatino
// {

// private:
//     int limitePlatino; //$500.000 <- settear por default
//     string titularPlatino;
//     long numeroTarjetaPlatino;
//     int codigoSegPlatino;
//     int fechaVencimientoPlatino;
//     float saldoTarjetaPlatino;

// public:
//     TarjetaPlatino();
//     TarjetaPlatino(int, string, long, int, int, float);

//     void setLimitePlatino(int);
//     void setTitularPlatino(string);
//     void setNumeroTarjetaPlatino(long);
//     void setCodigoSegPlatino(int);
//     void setFechaVencimientoTarPlatino(int);
//     void setSaldoOro(float);

//     int getLimitePlatino();
//     string getTitularPlatino();
//     long getNumeroTarjetaPlatino();
//     int getCodigoSegPlatino();
//     int getFechaVencimientoTarPlatino();
//     float getSaldoPlatino();

//     void mostrarSaldoTarjetaPlatino();  // muestra saldo disponible para gastar
//     void mostrarGastosTarjetaPlatino(); // muestra transacciones
// };

// class ClientePlatino : public Cliente
// {

// private:
//     string titularPlatino;
//     long usarioPlatino;
//     long clavePlatino;
//     float saldoPlatino;
//     TarjetaPlatino TarPlatino1;

// public:
//     ClientePlatino();
//     ClientePlatino(char, char, CADolares, CAPesos, string, long, long, float, TarjetaOro);

//     void setTitularPlatino(string);
//     void setUsuarioPlatino(long);
//     void setClavePlatino(long);
//     void setSaldoPlatino(float);

//     string getTitularPlatino();
//     long getUsuarioPlatino();
//     long getClavePlatino();
//     float getSaldoPlatino();

//     void mostrarSaldoClientePlatino();
//     void Extraccion();
//     void Desposito();
// };

